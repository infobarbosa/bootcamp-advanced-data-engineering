from .. import Provider as UserAgentProvider  # pragma: no cover


class Provider(UserAgentProvider):  # pragma: no cover
    pass
